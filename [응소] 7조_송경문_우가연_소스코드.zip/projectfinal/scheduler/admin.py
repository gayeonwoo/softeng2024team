from django.contrib import admin
from .models import Schedule

admin.site.register(Schedule)
